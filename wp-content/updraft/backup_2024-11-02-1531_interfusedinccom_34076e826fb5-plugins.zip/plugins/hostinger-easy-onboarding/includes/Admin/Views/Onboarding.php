<?php

use Hostinger\WpMenuManager\Menus;

echo Menus::renderMenuNavigation();
?>
<div id="hostinger-easy-onboarding-vue-app"/>
<?php